package com.madar.tube.download;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Environment;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.madar.tube.MadarApp;
import com.madar.tube.R;
import com.madar.tube.ui.MainActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class DownloadService extends Service {

    public static final String EXTRA_URL = "url";
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_QUALITY = "quality";

    private final ExecutorService executor = Executors.newFixedThreadPool(2);
    private final OkHttpClient client = new OkHttpClient();

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;

        String url = intent.getStringExtra(EXTRA_URL);
        String title = intent.getStringExtra(EXTRA_TITLE);
        String quality = intent.getStringExtra(EXTRA_QUALITY);

        if (url == null || title == null) return START_NOT_STICKY;

        startForeground(1, buildNotification(title, "Starting...", 0));

        executor.execute(() -> download(url, title, quality));

        return START_NOT_STICKY;
    }

    private void download(String url, String title, String quality) {
        try {
            File dir = new File(Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS), "MadarTube");
            if (!dir.exists()) dir.mkdirs();

            String safeName = title.replaceAll("[\\\\/:*?\"<>|]", "_");
            if (safeName.length() > 80) safeName = safeName.substring(0, 80);
            File outFile = new File(dir, safeName + " [" + quality + "].mp4");

            Request request = new Request.Builder().url(url).build();
            try (Response response = client.newCall(request).execute()) {
                if (!response.isSuccessful() || response.body() == null) {
                    updateNotification(title, "Failed", -1);
                    stopSelf();
                    return;
                }

                long total = response.body().contentLength();
                InputStream is = response.body().byteStream();
                FileOutputStream fos = new FileOutputStream(outFile);

                byte[] buffer = new byte[8192];
                long downloaded = 0;
                int read;
                int lastProgress = 0;

                while ((read = is.read(buffer)) != -1) {
                    fos.write(buffer, 0, read);
                    downloaded += read;

                    if (total > 0) {
                        int progress = (int) ((downloaded * 100) / total);
                        if (progress >= lastProgress + 2) {
                            lastProgress = progress;
                            updateNotification(title, progress + "%", progress);
                        }
                    }
                }

                fos.flush();
                fos.close();
                is.close();

                updateNotification(title, "تم ✓ → Download/MadarTube", 100);
            }
        } catch (Exception e) {
            Log.e("MadarTube", "Download error", e);
            updateNotification(title, "Error: " + e.getMessage(), -1);
        } finally {
            stopForeground(false);
            stopSelf();
        }
    }

    private Notification buildNotification(String title, String text, int progress) {
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, MadarApp.CHANNEL_ID)
                .setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentIntent(pi)
                .setOnlyAlertOnce(true)
                .setOngoing(progress >= 0 && progress < 100);

        if (progress >= 0 && progress < 100) {
            builder.setProgress(100, progress, false);
        } else {
            builder.setProgress(0, 0, false);
        }

        return builder.build();
    }

    private void updateNotification(String title, String text, int progress) {
        NotificationManagerCompat.notify(this, 1, buildNotification(title, text, progress));
    }

    // Simple helper to avoid extra import issues
    private static class NotificationManagerCompat {
        static void notify(Service service, int id, Notification notification) {
            android.app.NotificationManager nm =
                    (android.app.NotificationManager) service.getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(id, notification);
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
