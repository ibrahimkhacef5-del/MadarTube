package com.madar.tube.extractor;

import org.schabi.newpipe.extractor.NewPipe;
import org.schabi.newpipe.extractor.ServiceList;
import org.schabi.newpipe.extractor.stream.StreamInfo;
import org.schabi.newpipe.extractor.stream.VideoStream;
import org.schabi.newpipe.extractor.stream.AudioStream;
import org.schabi.newpipe.extractor.exceptions.ExtractionException;
import org.schabi.newpipe.extractor.localization.Localization;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Same tactic as Snaptube / NewPipe:
 * Extract video info + stream URLs without official API.
 */
public class VideoExtractor {

    static {
        // Init NewPipe
        NewPipe.init(DownloaderImpl.getInstance(), new Localization("en", "US"));
    }

    public static class ExtractResult {
        public String title;
        public String uploader;
        public String thumbnailUrl;
        public long duration;
        public List<StreamOption> videoOptions = new ArrayList<>();
        public List<StreamOption> audioOptions = new ArrayList<>();
        public String originalUrl;
    }

    public static class StreamOption {
        public String quality;
        public String format;
        public String url;
        public long size;
        public boolean isVideo;
        public int height;

        public StreamOption(String quality, String format, String url, long size, boolean isVideo, int height) {
            this.quality = quality;
            this.format = format;
            this.url = url;
            this.size = size;
            this.isVideo = isVideo;
            this.height = height;
        }

        @Override
        public String toString() {
            return quality + " • " + format.toUpperCase() + (size > 0 ? " • " + formatSize(size) : "");
        }

        private String formatSize(long bytes) {
            if (bytes < 1024) return bytes + " B";
            if (bytes < 1024 * 1024) return (bytes / 1024) + " KB";
            return String.format("%.1f MB", bytes / (1024.0 * 1024));
        }
    }

    public static ExtractResult extract(String url) throws ExtractionException, IOException {
        StreamInfo info = StreamInfo.getInfo(url);

        ExtractResult result = new ExtractResult();
        result.title = info.getName();
        result.uploader = info.getUploaderName();
        result.thumbnailUrl = info.getThumbnails().isEmpty() ? null : info.getThumbnails().get(0).getUrl();
        result.duration = info.getDuration();
        result.originalUrl = url;

        // Video streams
        for (VideoStream stream : info.getVideoOnlyStreams()) {
            result.videoOptions.add(new StreamOption(
                    stream.getResolution(),
                    stream.getFormat().getName(),
                    stream.getUrl(),
                    stream.getItagItem() != null ? stream.getItagItem().getContentLength() : 0,
                    true,
                    stream.getHeight()
            ));
        }

        // Muxed streams (video+audio)
        for (VideoStream stream : info.getVideoStreams()) {
            result.videoOptions.add(new StreamOption(
                    stream.getResolution() + " (with audio)",
                    stream.getFormat().getName(),
                    stream.getUrl(),
                    stream.getItagItem() != null ? stream.getItagItem().getContentLength() : 0,
                    true,
                    stream.getHeight()
            ));
        }

        // Audio only
        for (AudioStream stream : info.getAudioStreams()) {
            result.audioOptions.add(new StreamOption(
                    stream.getAverageBitrate() + " kbps",
                    stream.getFormat().getName(),
                    stream.getUrl(),
                    stream.getItagItem() != null ? stream.getItagItem().getContentLength() : 0,
                    false,
                    0
            ));
        }

        // Sort video by height desc
        result.videoOptions.sort((a, b) -> Integer.compare(b.height, a.height));

        return result;
    }
}
