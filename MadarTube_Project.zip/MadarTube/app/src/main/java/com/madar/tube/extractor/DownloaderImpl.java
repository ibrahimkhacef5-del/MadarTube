package com.madar.tube.extractor;

import org.schabi.newpipe.extractor.downloader.Downloader;
import org.schabi.newpipe.extractor.downloader.Request;
import org.schabi.newpipe.extractor.downloader.Response;
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;

public class DownloaderImpl extends Downloader {

    private static final DownloaderImpl INSTANCE = new DownloaderImpl();
    private final OkHttpClient client;

    public DownloaderImpl() {
        client = new OkHttpClient.Builder()
                .readTimeout(30, TimeUnit.SECONDS)
                .connectTimeout(15, TimeUnit.SECONDS)
                .build();
    }

    public static DownloaderImpl getInstance() {
        return INSTANCE;
    }

    @Override
    public Response execute(Request request) throws IOException, ReCaptchaException {
        okhttp3.Request.Builder builder = new okhttp3.Request.Builder()
                .url(request.url())
                .method(request.httpMethod(),
                        request.dataToSend() != null ?
                                RequestBody.create(request.dataToSend()) : null);

        for (Map.Entry<String, List<String>> entry : request.headers().entrySet()) {
            for (String value : entry.getValue()) {
                builder.addHeader(entry.getKey(), value);
            }
        }

        // Default UA (updated)
        if (!request.headers().containsKey("User-Agent")) {
            builder.header("User-Agent",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36");
        }

        try (okhttp3.Response response = client.newCall(builder.build()).execute()) {
            ResponseBody body = response.body();
            String responseBody = body != null ? body.string() : "";

            return new Response(
                    response.code(),
                    response.message(),
                    response.headers().toMultimap(),
                    responseBody,
                    response.request().url().toString()
            );
        }
    }
}
