package com.madar.tube.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.madar.tube.R;
import com.madar.tube.extractor.VideoExtractor;

public class MainActivity extends AppCompatActivity {

    private EditText urlInput;
    private Button extractBtn;
    private ProgressBar progressBar;
    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        urlInput = findViewById(R.id.urlInput);
        extractBtn = findViewById(R.id.extractBtn);
        progressBar = findViewById(R.id.progressBar);
        statusText = findViewById(R.id.statusText);

        extractBtn.setOnClickListener(v -> startExtract());
        findViewById(R.id.btnDownloads).setOnClickListener(v ->
                startActivity(new Intent(this, DownloadsActivity.class)));

        // Handle shared intent
        handleIncomingIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIncomingIntent(intent);
    }

    private void handleIncomingIntent(Intent intent) {
        if (intent == null) return;

        String action = intent.getAction();
        String url = null;

        if (Intent.ACTION_SEND.equals(action)) {
            url = intent.getStringExtra(Intent.EXTRA_TEXT);
        } else if (Intent.ACTION_VIEW.equals(action) && intent.getData() != null) {
            url = intent.getData().toString();
        }

        if (!TextUtils.isEmpty(url)) {
            urlInput.setText(url.trim());
            startExtract();
        }
    }

    private void startExtract() {
        String url = urlInput.getText().toString().trim();
        if (TextUtils.isEmpty(url)) {
            Toast.makeText(this, "حط الرابط أول", Toast.LENGTH_SHORT).show();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);
        extractBtn.setEnabled(false);
        statusText.setText("جاري استخراج المعلومات...");

        new Thread(() -> {
            try {
                VideoExtractor.ExtractResult result = VideoExtractor.extract(url);

                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    extractBtn.setEnabled(true);
                    statusText.setText("");

                    Intent i = new Intent(this, VideoDetailActivity.class);
                    i.putExtra("title", result.title);
                    i.putExtra("uploader", result.uploader);
                    i.putExtra("thumbnail", result.thumbnailUrl);
                    i.putExtra("duration", result.duration);
                    i.putExtra("url", result.originalUrl);

                    // Pass options as strings (simple way)
                    StringBuilder videos = new StringBuilder();
                    for (VideoExtractor.StreamOption opt : result.videoOptions) {
                        videos.append(opt.quality).append("|||")
                                .append(opt.format).append("|||")
                                .append(opt.url).append("|||")
                                .append(opt.size).append(";;;");
                    }
                    i.putExtra("video_options", videos.toString());

                    StringBuilder audios = new StringBuilder();
                    for (VideoExtractor.StreamOption opt : result.audioOptions) {
                        audios.append(opt.quality).append("|||")
                                .append(opt.format).append("|||")
                                .append(opt.url).append("|||")
                                .append(opt.size).append(";;;");
                    }
                    i.putExtra("audio_options", audios.toString());

                    startActivity(i);
                });
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> {
                    progressBar.setVisibility(View.GONE);
                    extractBtn.setEnabled(true);
                    statusText.setText("فشل الاستخراج: " + e.getMessage());
                    Toast.makeText(this, "خطأ: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }
}
