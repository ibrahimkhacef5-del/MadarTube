package com.madar.tube.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.madar.tube.R;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class DownloadsActivity extends AppCompatActivity {

    private ListView listView;
    private TextView emptyText;
    private List<File> files = new ArrayList<>();
    private DownloadAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_downloads);

        listView = findViewById(R.id.downloadsList);
        emptyText = findViewById(R.id.emptyText);
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());

        adapter = new DownloadAdapter();
        listView.setAdapter(adapter);

        loadFiles();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadFiles();
    }

    private void loadFiles() {
        files.clear();
        File dir = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOWNLOADS), "MadarTube");

        if (dir.exists() && dir.isDirectory()) {
            File[] list = dir.listFiles();
            if (list != null) {
                Arrays.sort(list, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
                Collections.addAll(files, list);
            }
        }

        emptyText.setVisibility(files.isEmpty() ? View.VISIBLE : View.GONE);
        adapter.notifyDataSetChanged();
    }

    private class DownloadAdapter extends BaseAdapter {
        @Override
        public int getCount() { return files.size(); }

        @Override
        public Object getItem(int position) { return files.get(position); }

        @Override
        public long getItemId(int position) { return position; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(DownloadsActivity.this)
                        .inflate(R.layout.item_download, parent, false);
            }

            File file = files.get(position);
            TextView title = convertView.findViewById(R.id.itemTitle);
            TextView path = convertView.findViewById(R.id.itemPath);
            TextView size = convertView.findViewById(R.id.itemSize);
            TextView btnOpen = convertView.findViewById(R.id.btnOpen);
            TextView btnDelete = convertView.findViewById(R.id.btnDelete);

            title.setText(file.getName());
            path.setText(file.getAbsolutePath());
            size.setText(formatSize(file.length()));

            btnOpen.setOnClickListener(v -> openFile(file));
            btnDelete.setOnClickListener(v -> confirmDelete(file));

            return convertView;
        }
    }

    private void openFile(File file) {
        try {
            Uri uri = FileProvider.getUriForFile(this,
                    getPackageName() + ".provider", file);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, "video/*");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, "فتح بـ"));
        } catch (Exception e) {
            Toast.makeText(this, "ما قدر يفتح الملف", Toast.LENGTH_SHORT).show();
        }
    }

    private void confirmDelete(File file) {
        new AlertDialog.Builder(this)
                .setTitle("حذف")
                .setMessage("تبي تحذف الملف؟\n" + file.getName())
                .setPositiveButton("حذف", (d, w) -> {
                    if (file.delete()) {
                        Toast.makeText(this, "تم الحذف", Toast.LENGTH_SHORT).show();
                        loadFiles();
                    } else {
                        Toast.makeText(this, "فشل الحذف", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return (bytes / 1024) + " KB";
        return String.format("%.1f MB", bytes / (1024.0 * 1024));
    }
}
