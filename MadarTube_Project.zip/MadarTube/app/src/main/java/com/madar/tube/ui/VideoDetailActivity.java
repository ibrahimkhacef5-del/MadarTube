package com.madar.tube.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.madar.tube.R;
import com.madar.tube.download.DownloadService;
import com.madar.tube.extractor.VideoExtractor;

import java.util.ArrayList;
import java.util.List;

public class VideoDetailActivity extends AppCompatActivity {

    private List<VideoExtractor.StreamOption> videoOptions = new ArrayList<>();
    private List<VideoExtractor.StreamOption> audioOptions = new ArrayList<>();
    private String title;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_detail);

        title = getIntent().getStringExtra("title");
        String uploader = getIntent().getStringExtra("uploader");
        String thumbnail = getIntent().getStringExtra("thumbnail");
        long duration = getIntent().getLongExtra("duration", 0);

        TextView titleView = findViewById(R.id.titleView);
        TextView uploaderView = findViewById(R.id.uploaderView);
        TextView durationView = findViewById(R.id.durationView);
        ImageView thumbView = findViewById(R.id.thumbView);
        ListView listView = findViewById(R.id.optionsList);

        titleView.setText(title != null ? title : "Unknown");
        uploaderView.setText(uploader != null ? uploader : "");
        durationView.setText(formatDuration(duration));

        if (thumbnail != null) {
            Glide.with(this).load(thumbnail).into(thumbView);
        }

        // Parse options
        parseOptions(getIntent().getStringExtra("video_options"), true);
        parseOptions(getIntent().getStringExtra("audio_options"), false);

        List<String> display = new ArrayList<>();
        for (VideoExtractor.StreamOption opt : videoOptions) {
            display.add("🎥 " + opt.toString());
        }
        for (VideoExtractor.StreamOption opt : audioOptions) {
            display.add("🎵 " + opt.toString());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, display);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            VideoExtractor.StreamOption selected;
            if (position < videoOptions.size()) {
                selected = videoOptions.get(position);
            } else {
                selected = audioOptions.get(position - videoOptions.size());
            }
            startDownload(selected);
        });
    }

    private void parseOptions(String raw, boolean isVideo) {
        if (raw == null || raw.isEmpty()) return;
        String[] items = raw.split(";;;");
        for (String item : items) {
            if (item.isEmpty()) continue;
            String[] parts = item.split("\\|\\|\\|");
            if (parts.length >= 3) {
                long size = parts.length > 3 ? Long.parseLong(parts[3]) : 0;
                VideoExtractor.StreamOption opt = new VideoExtractor.StreamOption(
                        parts[0], parts[1], parts[2], size, isVideo, 0);
                if (isVideo) videoOptions.add(opt);
                else audioOptions.add(opt);
            }
        }
    }

    private void startDownload(VideoExtractor.StreamOption option) {
        Intent service = new Intent(this, DownloadService.class);
        service.putExtra(DownloadService.EXTRA_URL, option.url);
        service.putExtra(DownloadService.EXTRA_TITLE, title);
        service.putExtra(DownloadService.EXTRA_QUALITY, option.quality);
        ContextCompat.startForegroundService(this, service);

        Toast.makeText(this, "بدأ التحميل: " + option.quality, Toast.LENGTH_SHORT).show();
        finish();
    }

    private String formatDuration(long seconds) {
        if (seconds <= 0) return "";
        long h = seconds / 3600;
        long m = (seconds % 3600) / 60;
        long s = seconds % 60;
        if (h > 0) return String.format("%d:%02d:%02d", h, m, s);
        return String.format("%d:%02d", m, s);
    }
}
