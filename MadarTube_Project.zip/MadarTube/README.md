# MadarTube

نسخة مفتوحة المصدر من تطبيقات التحميل (مثل Snaptube) باستخدام **NewPipe Extractor**.

## المميزات
- استخراج فيديو من YouTube / TikTok / Instagram / Facebook وغيرها
- اختيار الجودة
- تحميل في الخلفية مع إشعار
- واجهة عربية بسيطة ونظيفة
- بدون إعلانات

## التقنية المستخدمة
- Java
- NewPipe Extractor (نفس تكتيك NewPipe و Snaptube)
- OkHttp
- Glide
- Material Components

## كيف تفتح المشروع
1. افتح المجلد في **Android Studio** أو **CodeAssist**
2. Sync Gradle
3. Run على جهاز أو Emulator (minSdk 24)

## ملاحظات
- يحتاج إنترنت
- على أندرويد 10+ التحميل يروح لمجلد `Download/MadarTube`
- بعض المواقع تحتاج تحديث NewPipe Extractor من وقت لآخر

## الترخيص
مفتوح المصدر - استخدمه وعدل عليه بحرية.
